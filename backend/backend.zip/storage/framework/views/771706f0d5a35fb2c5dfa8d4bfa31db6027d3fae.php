<table>
    <thead>
        <?php if($type == 'loan_business' || $type == 'free_quote_business'): ?>
            <tr>
                <th>Business Type </th>
                <th>Money needs </th>
                <th>Financing for </th>
                <th>Start Business </th>
                <th>Annual Revenue </th>
                <th>Credit Profile </th>
                <th>Business Name </th>
                <th>Business Code </th>
                <th>Full Name </th>
                <th>Email</th>
                <th>Phone</th>
                <th>Registration date</th>
            </tr>
        <?php else: ?>
            <tr>
                <th>Residential Loans</th>
                <th>Home Description</th>
                <th>Property Use</th>
                <th>Plan to Purchase Your Home</th>
                <th>Estimated Purchase Price</th>
                <th>Mortgage Balance</th>
                <th>Want to refinance because</th>
                <th>Borrow additional cash</th>
                <th>Estimated Purchase Price</th>
                <th>Putting down as a down payment</th>
                <th>First Time Home Buyer?</th>
                <th>Credit Profile</th>
                <th>Currently employed?</th>
                <th>Business Code </th>
                <th>Full Name </th>
                <th>Email</th>
                <th>Phone</th>
                <th>Registration date</th>
            </tr>
        <?php endif; ?>
    </thead>
    <tbody>
        <?php if($type == 'loan_business' || $type == 'free_quote_business'): ?>
            <?php $__currentLoopData = $flowsForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($form->business_own); ?></td>
                    <td><?php echo e($form->money_need); ?></td>
                    <td><?php echo e($form->finance_for); ?></td>
                    <td><?php echo e($form->month_start); ?> / <?php echo e($form->yeart_start); ?> </td>
                    <td><?php echo e($form->annual_revenue); ?></td>
                    <td><?php echo e($form->credit_profile); ?></td>
                    <td><?php echo e($form->business_name); ?></td>
                    <td><?php echo e($form->business_code); ?></td>
                    <td><?php echo e($form->full_name); ?></td>
                    <td><?php echo e($form->email); ?></td>
                    <td><?php echo e($form->phone_number); ?></td>
                    <td><?php echo e($form->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $flowsForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($form->residential_loans); ?></td>
                    <td><?php echo e($form->home_description); ?></td>
                    <td><?php echo e($form->property_use); ?></td>
                    <td>
                        <?php if($form->plan_to_purchase): ?>
                            <?php echo e($form->plan_to_purchase); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->estimated_value_property && $form->residential_loans == 'Cash Out'): ?>
                            $ <?php echo e($form->estimated_value_property); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->residential_loans == 'Cash Out'): ?>
                            $ <?php echo e(($form->estimated_value_property * $form->morgate_balance) / 100); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->want_to_refinance): ?>
                            <?php echo e($form->want_to_refinance); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->additional_cash): ?>
                            $ <?php echo e($form->additional_cash); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->residential_loans == 'Cash Out'): ?>
                            ---
                        <?php else: ?>
                            $ <?php echo e($form->estimated_purchase_price); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->residential_loans == 'Cash Out'): ?>
                            ---
                        <?php else: ?>
                            <?php echo e($form->down_payment); ?> %
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->first_time_buyer): ?>
                            <?php echo e($form->first_time_buyer); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($form->credit_profile): ?>
                            <?php echo e($form->credit_profile); ?>

                        <?php else: ?>
                            ---
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($form->currently_employed); ?></td>
                    <td><?php echo e($form->business_code); ?></td>
                    <td><?php echo e($form->full_name); ?></td>
                    <td><?php echo e($form->email); ?></td>
                    <td><?php echo e($form->phone_number); ?></td>
                    <td><?php echo e($form->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\Tony\Informacion_tony\SoftwareDevelopment\Freelos\us-mortgage\backend\resources\views/export.blade.php ENDPATH**/ ?>