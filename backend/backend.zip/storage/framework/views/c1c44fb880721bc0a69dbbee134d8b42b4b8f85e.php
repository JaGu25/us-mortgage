<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Babe Correo</title>
</head>
<body>
    <p>Ha llegado un correo de la siguiente persona:</p>
    <p>Nombre y Apellidos: <?php echo e($correo->nombre); ?>.</p>
    <p>Email: <?php echo e($correo->email); ?>.</p>
    <p>Dirección: <?php echo e($correo->direccion); ?>.</p>
    <p>Motivo: <?php echo e($correo->motivo); ?>.</p>
    <p>Mensaje: <?php echo e($correo->mensaje); ?>.</p>
    <p>Consiento el tratamiento de datos de carácter personal aquí descrito : <?php echo e($correo->consentimiento); ?>.</p>
    <p>Me gustaría recibir información y nuevas promociones sobre productos BABÉ : <?php echo e($correo->informacion); ?>.</p>
</body>
</html><?php /**PATH C:\Tony\Informacion_tony\SoftwareDevelopment\Freelos\babe\backend\resources\views/mails/babe.blade.php ENDPATH**/ ?>