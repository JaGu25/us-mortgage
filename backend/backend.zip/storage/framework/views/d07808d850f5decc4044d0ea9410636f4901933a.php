<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body style="margin: 0; padding: 0;">
    <table cellpadding="0" cellspacing="0" border="0" align="center" style="color:white; max-width: 700px; width: 100%;">
        <tr valign="top">
            <td style="background-color: white;">
                <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color: white;">
                    <tr valign="top">
                        <td>
                            <img style="border: 0; display: block;width: 100%;" src="https://mcusercontent.com/92293298e1780583d507d0eb3/images/c6e26e5c-a07e-0940-713e-1ddf3aa329d5.jpg" />
                        </td>
                    </tr>
                    <tr>
                        <td align="left" style="padding-left: 20px;padding-right: 20px;background-color: #1f284c;">
                            <p style="color: white;font-family: Arial, sans-serif;font-style: normal;font-weight: 300;font-size: 16px;margin:22px 0px 22px 0px;"><b style="color: white;font-weight: 700;">Thanks for contacting us,</b> <?php echo e($form->full_name); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" style="padding: 80px 18%;text-align: center;">
                            <p style="color: #414141;font-family: Arial, sans-serif;font-style: normal;font-weight: 500;font-size: 16px;margin:22px 0px 22px 0px;">We received your inquiry. We will provide you with a Free personalized information and one-on-one consultation.</p>
                            <p style="color: #414141;font-family: Arial, sans-serif;font-style: normal;font-weight: 500;font-size: 16px;margin:22px 0px 22px 0px;">One of our experts will call you shortly.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #c00000;padding: 20px 0;text-align: center;width: 100%;">
                            <table width="100%">
                                <tr style="width: 100%;">
                                    <td colspan="3">
                                         <p style="color: white;font-family: Arial, sans-serif;font-style: normal;font-weight: 700;font-size: 16px;margin:5px 0px;">Follow Us!</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="justify" style="padding-left: 10px;padding-right: 10px;text-align: right;width: 45%;">
                                        <a href="https://www.facebook.com/usmortgagewholesale"><img style="width:25px;" src="https://mcusercontent.com/92293298e1780583d507d0eb3/images/dd311a59-f8d9-3df4-b370-af24ce521209.png" alt=""></a>
                                    </td>
                                    <td align="justify" style="padding-left: 10px;padding-right: 10px; text-align: center;width: 10%;">
                                        <a href="https://www.youtube.com/channel/UCEM7S6tis1WrjZ1VCcML30g"><img style="width:25px;" src="https://mcusercontent.com/92293298e1780583d507d0eb3/images/f114bee2-5130-890c-eba7-71833708b555.png" alt=""></a>
                                    </td>
                                    <td align="justify" style="padding-left: 10px;padding-right: 10px;text-align: left;width: 45%;">
                                        <a href="https://instagram.com/usmortgagewholesale?utm_medium=copy_link"><img style="width:25px;" src="https://mcusercontent.com/92293298e1780583d507d0eb3/images/c0c7001d-f33d-93b5-367a-1432e5795ce0.png" alt=""></a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\Tony\Informacion_tony\SoftwareDevelopment\Freelos\us-mortgage\backend\resources\views/mails/mortgage.blade.php ENDPATH**/ ?>