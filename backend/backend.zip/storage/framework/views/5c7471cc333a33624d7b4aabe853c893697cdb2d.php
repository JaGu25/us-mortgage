<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body style="margin: 0; padding: 0;">
    <p>
        <?php echo e($form->first_name); ?> / <?php echo e($form->type); ?>

    </p>
</body>
</html><?php /**PATH C:\Tony\Informacion_tony\SoftwareDevelopment\Freelos\us-mortgage\backend\resources\views/mails/notification.blade.php ENDPATH**/ ?>