<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Babe Correo</title>
</head>
<body>
   1
</body>
</html><?php /**PATH C:\Tony\Informacion_tony\SoftwareDevelopment\Freelos\us-mortgage\backend\resources\views/mails/babe.blade.php ENDPATH**/ ?>