<?php

namespace App\Enums;


class FlowTypes
{
    const REDENTIAL   =   'residential';
    const COMMERCIAL  =   'commercial';
}